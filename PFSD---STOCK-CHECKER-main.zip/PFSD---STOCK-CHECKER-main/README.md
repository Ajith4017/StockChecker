# PFSD---STOCK-CHECKER
STOCK CHECKER: Stock Informer is the real time stock checker that helps you to track down those hard to find products.The website application is self maintained There is no need provide post implementation support.The admin can access all the CRUD.
